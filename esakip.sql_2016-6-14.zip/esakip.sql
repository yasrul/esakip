-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 14, 2016 at 08:31 AM
-- Server version: 5.5.49-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `esakip`
--

-- --------------------------------------------------------

--
-- Table structure for table `indikator_kinerja`
--

CREATE TABLE IF NOT EXISTS `indikator_kinerja` (
  `id` int(11) NOT NULL,
  `id_sasaran` varchar(12) NOT NULL,
  `indikator` varchar(255) NOT NULL,
  `satuan` varchar(25) NOT NULL,
  `formulasi` varchar(255) NOT NULL,
  `sumber_data` varchar(255) NOT NULL,
  KEY `id_sasaran` (`id_sasaran`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kebijakan`
--

CREATE TABLE IF NOT EXISTS `kebijakan` (
  `id` varchar(14) NOT NULL,
  `id_strategi` varchar(12) NOT NULL,
  `kebijakan` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_strategi` (`id_strategi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1461210533),
('m130524_201442_init', 1461210544);

-- --------------------------------------------------------

--
-- Table structure for table `misi`
--

CREATE TABLE IF NOT EXISTS `misi` (
  `id` varchar(6) NOT NULL,
  `id_renstra` varchar(4) NOT NULL,
  `misi` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_renstra` (`id_renstra`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `periode`
--

CREATE TABLE IF NOT EXISTS `periode` (
  `id` varchar(2) NOT NULL,
  `tahun_awal` smallint(4) unsigned NOT NULL,
  `tahun_akhir` smallint(4) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `periode`
--

INSERT INTO `periode` (`id`, `tahun_awal`, `tahun_akhir`) VALUES
('01', 2014, 2018);

-- --------------------------------------------------------

--
-- Table structure for table `program`
--

CREATE TABLE IF NOT EXISTS `program` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_sasaran` varchar(10) NOT NULL,
  `id_ref_program` int(11) NOT NULL,
  `anggaran` float NOT NULL,
  `sumber` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ref_program` (`id_ref_program`),
  KEY `id_sasaran` (`id_sasaran`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ref_program`
--

CREATE TABLE IF NOT EXISTS `ref_program` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `renstra`
--

CREATE TABLE IF NOT EXISTS `renstra` (
  `id` varchar(4) NOT NULL,
  `id_skpd` varchar(2) NOT NULL,
  `id_periode` varchar(2) NOT NULL,
  `visi` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_skpd` (`id_skpd`),
  KEY `id_periode` (`id_periode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `renstra`
--

INSERT INTO `renstra` (`id`, `id_skpd`, `id_periode`, `visi`) VALUES
('0301', '03', '01', 'Visi Biro Hukum'),
('0501', '05', '01', 'Visi Biro Administrasi Pembangunan'),
('0701', '07', '01', 'Visi Biro Umum');

-- --------------------------------------------------------

--
-- Table structure for table `sasaran`
--

CREATE TABLE IF NOT EXISTS `sasaran` (
  `id` varchar(10) NOT NULL,
  `id_tujuan` varchar(8) NOT NULL,
  `sasaran` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_tujuan` (`id_tujuan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `skpd`
--

CREATE TABLE IF NOT EXISTS `skpd` (
  `id` varchar(2) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `inisial` varchar(50) NOT NULL,
  `alamat` varchar(200) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `pj_sakip` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skpd`
--

INSERT INTO `skpd` (`id`, `nama`, `inisial`, `alamat`, `phone`, `email`, `pj_sakip`) VALUES
('01', 'Biro Administrasi Pemerintahan', 'Biro Pemerintahan', '', '', '', ''),
('02', 'Biro Hukum', 'Biro Hukum', '', '', '', ''),
('03', 'Biro Organisasi', 'Biro Organisasi', '', '', '', ''),
('04', 'Biro Administrasi Perekonomian', 'Biro Ekonomi', '', '', '', ''),
('05', 'Biro Administrasi Pembangunan', 'Biro AP', '', '', '', ''),
('06', 'Biro Administrasi Kerjasama dan SDA', 'Biro KSDA', '', '', '', ''),
('07', 'Biro Umum', 'Biro Umum', '', '', '', ''),
('08', 'Biro Humas dan Protokol', 'Biro HP', '', '', '', ''),
('09', 'Biro Administrasi Kesejahteraan Rakyat', 'Biro Kesra', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `strategi`
--

CREATE TABLE IF NOT EXISTS `strategi` (
  `id` varchar(12) NOT NULL,
  `id_sasaran` varchar(10) NOT NULL,
  `strategi` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_sasaran` (`id_sasaran`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `target_realisasi`
--

CREATE TABLE IF NOT EXISTS `target_realisasi` (
  `id` int(11) NOT NULL,
  `id_indikator` int(11) NOT NULL,
  `tahun` int(11) NOT NULL,
  `triwulan` int(11) NOT NULL,
  `target` float NOT NULL,
  `realisasi` float NOT NULL,
  `analisis` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tujuan`
--

CREATE TABLE IF NOT EXISTS `tujuan` (
  `id` varchar(8) NOT NULL,
  `id_misi` varchar(6) NOT NULL,
  `tujuan` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_misi` (`id_misi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin', '', '$2y$13$dTARTmzYuhzgD0luwVgfDexpc0FrT/SGuOgqqpV2oCsy42w/MOh3K', NULL, 'yasrul@gmail.com', 10, 0, 0),
(2, 'yasrul', 'UqzdPXfxR1V_AsgDagf2BGnTjsBGrJDQ', '$2y$13$uh7OXxGwgwHgkicXhO3tfex7IOimuILC2s.WgdfrqwENDjR6n099G', NULL, 'yasrul93@gmail.com', 10, 2016, 2016);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `indikator_kinerja`
--
ALTER TABLE `indikator_kinerja`
  ADD CONSTRAINT `indikator_kinerja_ibfk_1` FOREIGN KEY (`id_sasaran`) REFERENCES `sasaran` (`id`);

--
-- Constraints for table `kebijakan`
--
ALTER TABLE `kebijakan`
  ADD CONSTRAINT `kebijakan_ibfk_1` FOREIGN KEY (`id_strategi`) REFERENCES `strategi` (`id`);

--
-- Constraints for table `misi`
--
ALTER TABLE `misi`
  ADD CONSTRAINT `misi_ibfk_1` FOREIGN KEY (`id_renstra`) REFERENCES `renstra` (`id`);

--
-- Constraints for table `program`
--
ALTER TABLE `program`
  ADD CONSTRAINT `program_ibfk_1` FOREIGN KEY (`id_sasaran`) REFERENCES `sasaran` (`id`),
  ADD CONSTRAINT `program_ibfk_2` FOREIGN KEY (`id_ref_program`) REFERENCES `ref_program` (`id`);

--
-- Constraints for table `renstra`
--
ALTER TABLE `renstra`
  ADD CONSTRAINT `renstra_ibfk_1` FOREIGN KEY (`id_skpd`) REFERENCES `skpd` (`id`),
  ADD CONSTRAINT `renstra_ibfk_2` FOREIGN KEY (`id_periode`) REFERENCES `periode` (`id`);

--
-- Constraints for table `sasaran`
--
ALTER TABLE `sasaran`
  ADD CONSTRAINT `sasaran_ibfk_1` FOREIGN KEY (`id_tujuan`) REFERENCES `tujuan` (`id`);

--
-- Constraints for table `strategi`
--
ALTER TABLE `strategi`
  ADD CONSTRAINT `strategi_ibfk_1` FOREIGN KEY (`id_sasaran`) REFERENCES `sasaran` (`id`);

--
-- Constraints for table `tujuan`
--
ALTER TABLE `tujuan`
  ADD CONSTRAINT `tujuan_ibfk_1` FOREIGN KEY (`id_misi`) REFERENCES `misi` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
